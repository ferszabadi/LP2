﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Double numero1, numero2, resultadoOperacao;


        private void button3_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txtNumero1.Text, out numero1) && Double.TryParse(txtNumero2.Text, out numero2))
            {
                resultadoOperacao = numero1 + numero2;
                txtResultado.Text = resultadoOperacao.ToString();
            }
            else
            {
                MessageBox.Show("Não é possível realizar operação com letra. Digite um número.");
                txtNumero1.Focus();
            }
        }

        private void btnSair_Leave(object sender, EventArgs e)
        {
        
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
            txtResultado.Clear();

            txtNumero1.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnSubtracao_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txtNumero1.Text, out numero1) && Double.TryParse(txtNumero2.Text, out numero2))
            {
                resultadoOperacao = numero1 - numero2;
                txtResultado.Text = resultadoOperacao.ToString();
            }
            else
            {
                MessageBox.Show("Não é possível realizar operação com letra. Digite um número.");
                txtNumero1.Focus();
            }
        }

        private void btnMultiplicacao_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txtNumero1.Text, out numero1) && Double.TryParse(txtNumero2.Text, out numero2))
            {
                resultadoOperacao = numero1 * numero2;
                txtResultado.Text = resultadoOperacao.ToString();
            }
            else
            {
                MessageBox.Show("Não é possível realizar operação com letra. Digite um número.");
                txtNumero1.Focus();
            }
        }

        private void btnDivisao_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txtNumero1.Text, out numero1) && Double.TryParse(txtNumero2.Text, out numero2))
            {
                if (numero2 == 0)
                {
                    MessageBox.Show("Não é possível divisão por zero.");
                }
                else
                {
                    resultadoOperacao = numero1 / numero2;
                    txtResultado.Text = resultadoOperacao.ToString();
                }
            }
            else
            {
                MessageBox.Show("Não é possível realizar operação com letra. Digite um número.");
                txtNumero1.Focus();
            }
        }
    }
}
