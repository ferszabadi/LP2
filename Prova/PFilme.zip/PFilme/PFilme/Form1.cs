﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PFilme
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[60,2];
            int i, j;
            double mediaFilme1 = 0, mediaFilme2 = 0;
            double tempNota1=0, tempNota2=0;
            string auxiliar="";

            //Receber os dados

            for (i = 0; i < 60; i++)
            {

                for (j = 0; j < 2; j++)
                {
                    auxiliar = Interaction.InputBox("Pessoa " + (i + 1) + ", digite a nota do filme " + (j + 1) + ":");

                    //Testa se foi digitado um valor diferente de double
                    if (!double.TryParse(auxiliar, out notas[i, j]))
                    {
                        MessageBox.Show("Nota inválida!");
                        j--;
                    }
                    else
                    {
                        //Testa se a nota está entre 0 e 10
                        if ((notas[i, j] < 0) || (notas[i, j] > 10))
                        {
                            MessageBox.Show("A nota deve estar entre 0 e 10!");
                            i--;
                        }

                        //Faz a somatória das notas
                        if (j == 0)
                        {
                            mediaFilme1 += notas[i, j];
                            tempNota1 = notas[i, j];
                        }
                        else
                        {
                            mediaFilme2 += notas[i, j];
                            tempNota2 = notas[i, j];
                        }

                    }
                }

                //Exibe as notas individualmente
                lstbxFilmes.Items.Add("Pessoa " + (i + 1) + " | Nota Filme 1: " + tempNota1.ToString() + " | Nota Filme 2: " + tempNota2.ToString());

            }

            //Calcula a média das notas dos filmes
            mediaFilme1 = mediaFilme1 / 60;
            mediaFilme2 = mediaFilme2 / 60;

            //Exibe as médias finais
            lstbxFilmes.Items.Add("-------------------------------------------");
            lstbxFilmes.Items.Add("Média Filme 1: " + mediaFilme1.ToString("N2"));
            lstbxFilmes.Items.Add("Média Filme 2: " + mediaFilme2.ToString("N2"));

        }

    }
}
