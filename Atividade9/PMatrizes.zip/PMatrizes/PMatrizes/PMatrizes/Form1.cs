﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnInverteVetor_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar;

            for (var i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox("Digite um número: ", "Entrada de Dados");
                if(!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Valor inválido!");
                    i--;
                }

            }

            Array.Reverse(vetor);
            auxiliar = "";
            foreach (int result in vetor)
            {
                auxiliar += result + "\n";
            }

            MessageBox.Show(auxiliar);
        }

        private void btnMercadoria_Click(object sender, EventArgs e)
        {
            double[] quantidade = new double[10];
            double[] preco = new double[10];
            string auxiliar;
            double faturamento = 0;

            for (var i = 0; i < quantidade.Length; i++)
            {
                auxiliar = Interaction.InputBox("Digite a quantidade da mercadoria " + (i+1),
                    "Entrada de Dados");
               if(!double.TryParse(auxiliar, out quantidade[i]))
               {
                    MessageBox.Show("Quantidade Inválida!");
                    i--;
               }
               else 
               {

                    while (preco[i] <= 0)
                    {
                        auxiliar = Interaction.InputBox("Digite o preço da mercadoria " + (i+1),
                            "Entrada dos Preços");
                        if(!double.TryParse(auxiliar, out preco[i]))
                        {
                            MessageBox.Show("Preço inválido!");
                        }
                        else
                        {
                            if (preco[i]<=0)
                            {
                                MessageBox.Show("O preço deve ser maior do que zero!");
                            }
                        }
                    }

                    faturamento += quantidade[i] * preco[i];
                
               }
            }

            MessageBox.Show("O faturamento é: " + faturamento.ToString("N2"));
        }

        private void btnTotal_Click(object sender, EventArgs e)
        {
            string[] alunos = {"Viviane", "André", "Hélio", "Denise", "Junior", "Leonardo",
                               "Jose", "Nelma", "Tobby"};
            Int32 i, total = 0;
            Int32 n = alunos.Length;

            for (i=0; i<n-1; i++)
            {
                total += alunos[i].Length;
            }

            MessageBox.Show(total.ToString());
        }

        private void btnNomes_Click(object sender, EventArgs e)
        {
            frmNomesPessoas frmNP = new frmNomesPessoas();
            frmNP.Show();
        }

        private void btnMediaAlunos_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];

            int x, y = 0;
            double media = 0, somaNotas=0;
            string auxiliar = "";

            for (x = 0; x < 20; x++)
            {

                for (y = 0; y < 3; y++)
                {
                    auxiliar = Interaction.InputBox("Digite a nota " + (y+1) + " para o aluno " + (x + 1) + ":");

                    if (!double.TryParse(auxiliar, out notas[x,y]))
                    {
                        MessageBox.Show("Nota inválida");
                        y--;
                    }
                    else
                    {
                        if ((notas[x,y] < 0) || (notas[x,y] > 10))
                        {
                            MessageBox.Show("Nota deve estar entre 0 e 10");
                            y--;
                        }

                        somaNotas += notas[x,y];
                        media = (somaNotas/3);

                    }

                }

                MessageBox.Show("A média do aluno " + (x + 1).ToString() + " é " + media.ToString());

                media = 0;
                somaNotas = 0;
            }
        }

        private void btnArrayList_Click(object sender, EventArgs e)
        {
            ArrayList listaAlunos = new ArrayList()
            {
                "Ana",
                "André",
                "Débora",
                "Fátima",
                "João",
                "Janete",
                "Otávio",
                "Marcelo",
                "Pedro",
                "Thais"
            };

            listaAlunos.Remove("Otávio");

            //Exibe, porém um nome por janela
            /*foreach (string aluno in listaAlunos)
                MessageBox.Show(aluno);*/

            //Exibe a lista completa em apenas 1 janela
            int i = 0;
            MessageBox.Show("Nova ArrayList: " + "\n" + listaAlunos[i].ToString() + "\n" + listaAlunos[i + 1].ToString() + "\n" + listaAlunos[i + 2].ToString() + "\n" + listaAlunos[i + 3].ToString() + "\n" + listaAlunos[i + 4].ToString() + "\n" + listaAlunos[i + 5].ToString() + "\n" + listaAlunos[i + 6].ToString() + "\n" + listaAlunos[i + 7].ToString() + "\n" + listaAlunos[i + 8].ToString());
        }
    }
}
