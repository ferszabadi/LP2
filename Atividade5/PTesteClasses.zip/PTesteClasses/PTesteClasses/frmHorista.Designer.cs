﻿namespace PTesteClasses
{
    partial class frmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtDiasFaltas = new System.Windows.Forms.TextBox();
            this.txtSalarioH = new System.Windows.Forms.TextBox();
            this.txtNumHoras = new System.Windows.Forms.TextBox();
            this.txtDataEntrada = new System.Windows.Forms.TextBox();
            this.lblMatricula = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalarioPorHora = new System.Windows.Forms.Label();
            this.lblNumeroDeHoras = new System.Windows.Forms.Label();
            this.lblDataEntrada = new System.Windows.Forms.Label();
            this.lblDiasFaltas = new System.Windows.Forms.Label();
            this.btnInstanciarH = new System.Windows.Forms.Button();
            this.gbxHome = new System.Windows.Forms.GroupBox();
            this.rbtnSim = new System.Windows.Forms.RadioButton();
            this.rbtnNao = new System.Windows.Forms.RadioButton();
            this.gbxHome.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(296, 127);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(100, 20);
            this.txtMatricula.TabIndex = 0;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(296, 165);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(100, 20);
            this.txtNome.TabIndex = 1;
            // 
            // txtDiasFaltas
            // 
            this.txtDiasFaltas.Location = new System.Drawing.Point(296, 311);
            this.txtDiasFaltas.Name = "txtDiasFaltas";
            this.txtDiasFaltas.Size = new System.Drawing.Size(100, 20);
            this.txtDiasFaltas.TabIndex = 2;
            // 
            // txtSalarioH
            // 
            this.txtSalarioH.Location = new System.Drawing.Point(296, 201);
            this.txtSalarioH.Name = "txtSalarioH";
            this.txtSalarioH.Size = new System.Drawing.Size(100, 20);
            this.txtSalarioH.TabIndex = 3;
            // 
            // txtNumHoras
            // 
            this.txtNumHoras.Location = new System.Drawing.Point(296, 235);
            this.txtNumHoras.Name = "txtNumHoras";
            this.txtNumHoras.Size = new System.Drawing.Size(100, 20);
            this.txtNumHoras.TabIndex = 4;
            // 
            // txtDataEntrada
            // 
            this.txtDataEntrada.Location = new System.Drawing.Point(296, 272);
            this.txtDataEntrada.Name = "txtDataEntrada";
            this.txtDataEntrada.Size = new System.Drawing.Size(100, 20);
            this.txtDataEntrada.TabIndex = 5;
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMatricula.Location = new System.Drawing.Point(203, 124);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(87, 23);
            this.lblMatricula.TabIndex = 6;
            this.lblMatricula.Text = "Matrícula";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome.Location = new System.Drawing.Point(232, 161);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(58, 23);
            this.lblNome.TabIndex = 7;
            this.lblNome.Text = "Nome";
            // 
            // lblSalarioPorHora
            // 
            this.lblSalarioPorHora.AutoSize = true;
            this.lblSalarioPorHora.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalarioPorHora.Location = new System.Drawing.Point(153, 197);
            this.lblSalarioPorHora.Name = "lblSalarioPorHora";
            this.lblSalarioPorHora.Size = new System.Drawing.Size(137, 23);
            this.lblSalarioPorHora.TabIndex = 8;
            this.lblSalarioPorHora.Text = "Salário por Hora";
            // 
            // lblNumeroDeHoras
            // 
            this.lblNumeroDeHoras.AutoSize = true;
            this.lblNumeroDeHoras.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumeroDeHoras.Location = new System.Drawing.Point(141, 231);
            this.lblNumeroDeHoras.Name = "lblNumeroDeHoras";
            this.lblNumeroDeHoras.Size = new System.Drawing.Size(149, 23);
            this.lblNumeroDeHoras.TabIndex = 9;
            this.lblNumeroDeHoras.Text = "Número de Horas";
            // 
            // lblDataEntrada
            // 
            this.lblDataEntrada.AutoSize = true;
            this.lblDataEntrada.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDataEntrada.Location = new System.Drawing.Point(59, 268);
            this.lblDataEntrada.Name = "lblDataEntrada";
            this.lblDataEntrada.Size = new System.Drawing.Size(231, 23);
            this.lblDataEntrada.TabIndex = 10;
            this.lblDataEntrada.Text = "Data de Entrada na Empresa";
            // 
            // lblDiasFaltas
            // 
            this.lblDiasFaltas.AutoSize = true;
            this.lblDiasFaltas.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDiasFaltas.Location = new System.Drawing.Point(172, 307);
            this.lblDiasFaltas.Name = "lblDiasFaltas";
            this.lblDiasFaltas.Size = new System.Drawing.Size(118, 23);
            this.lblDiasFaltas.TabIndex = 11;
            this.lblDiasFaltas.Text = "Dias de Faltas";
            // 
            // btnInstanciarH
            // 
            this.btnInstanciarH.Location = new System.Drawing.Point(276, 399);
            this.btnInstanciarH.Name = "btnInstanciarH";
            this.btnInstanciarH.Size = new System.Drawing.Size(171, 64);
            this.btnInstanciarH.TabIndex = 12;
            this.btnInstanciarH.Text = "Instanciar Horista";
            this.btnInstanciarH.UseVisualStyleBackColor = true;
            this.btnInstanciarH.Click += new System.EventHandler(this.btnInstanciarH_Click);
            // 
            // gbxHome
            // 
            this.gbxHome.Controls.Add(this.rbtnNao);
            this.gbxHome.Controls.Add(this.rbtnSim);
            this.gbxHome.Location = new System.Drawing.Point(459, 127);
            this.gbxHome.Name = "gbxHome";
            this.gbxHome.Size = new System.Drawing.Size(200, 100);
            this.gbxHome.TabIndex = 13;
            this.gbxHome.TabStop = false;
            this.gbxHome.Text = "Trabalha em home office";
            // 
            // rbtnSim
            // 
            this.rbtnSim.AutoSize = true;
            this.rbtnSim.Location = new System.Drawing.Point(3, 16);
            this.rbtnSim.Name = "rbtnSim";
            this.rbtnSim.Size = new System.Drawing.Size(42, 17);
            this.rbtnSim.TabIndex = 0;
            this.rbtnSim.Text = "Sim";
            this.rbtnSim.UseVisualStyleBackColor = true;
            // 
            // rbtnNao
            // 
            this.rbtnNao.AutoSize = true;
            this.rbtnNao.Checked = true;
            this.rbtnNao.Location = new System.Drawing.Point(3, 39);
            this.rbtnNao.Name = "rbtnNao";
            this.rbtnNao.Size = new System.Drawing.Size(45, 17);
            this.rbtnNao.TabIndex = 1;
            this.rbtnNao.TabStop = true;
            this.rbtnNao.Text = "Não";
            this.rbtnNao.UseVisualStyleBackColor = true;
            // 
            // frmHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(728, 553);
            this.Controls.Add(this.gbxHome);
            this.Controls.Add(this.btnInstanciarH);
            this.Controls.Add(this.lblDiasFaltas);
            this.Controls.Add(this.lblDataEntrada);
            this.Controls.Add(this.lblNumeroDeHoras);
            this.Controls.Add(this.lblSalarioPorHora);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblMatricula);
            this.Controls.Add(this.txtDataEntrada);
            this.Controls.Add(this.txtNumHoras);
            this.Controls.Add(this.txtSalarioH);
            this.Controls.Add(this.txtDiasFaltas);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMatricula);
            this.Name = "frmHorista";
            this.Text = "frmHorista";
            this.gbxHome.ResumeLayout(false);
            this.gbxHome.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtDiasFaltas;
        private System.Windows.Forms.TextBox txtSalarioH;
        private System.Windows.Forms.TextBox txtNumHoras;
        private System.Windows.Forms.TextBox txtDataEntrada;
        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalarioPorHora;
        private System.Windows.Forms.Label lblNumeroDeHoras;
        private System.Windows.Forms.Label lblDataEntrada;
        private System.Windows.Forms.Label lblDiasFaltas;
        private System.Windows.Forms.Button btnInstanciarH;
        private System.Windows.Forms.GroupBox gbxHome;
        private System.Windows.Forms.RadioButton rbtnNao;
        private System.Windows.Forms.RadioButton rbtnSim;
    }
}