﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnNumerico_Click(object sender, EventArgs e)
        {

            string textoString, contfinal;
            int tamanhoString, cont=0;
            
            textoString = rchtxtExercicio4.Text.ToString();
            tamanhoString = rchtxtExercicio4.TextLength;

            for (int i= 0; i < tamanhoString; i++)
            {
                if (char.IsNumber(textoString[i]))
                    cont++;
            }

            contfinal = cont.ToString();

            MessageBox.Show("Há " + contfinal + " caracteres numéricos.");
        }

        private void btnEspaco_Click(object sender, EventArgs e)
        {
            string textoString, posicao;
            int tamanhoString, i = 0;

            textoString = rchtxtExercicio4.Text.ToString();
            tamanhoString = rchtxtExercicio4.TextLength;

            while (i < tamanhoString)
            {
                if (char.IsWhiteSpace(textoString[i]))
                {
                    posicao = i.ToString();
                    MessageBox.Show("A posição do primeiro espaço em branco é " + i + ".");
                    break;
                }
                else
                    i++;
            }
        }

        private void btnAlfabetico_Click(object sender, EventArgs e)
        {
            string textoString, contfinal;
            int cont = 0;

            textoString = rchtxtExercicio4.Text.ToString();

            foreach (char caractereAlfabetico in textoString)
            {
                if (char.IsLetter(caractereAlfabetico))
                    cont++;
            }

            contfinal = cont.ToString();

            MessageBox.Show("Há " + contfinal + " caracteres alfabéticos.");

        }
    }
}
