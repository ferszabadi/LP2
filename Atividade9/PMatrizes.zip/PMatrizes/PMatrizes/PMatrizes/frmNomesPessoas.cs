﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class frmNomesPessoas : Form
    {
        public frmNomesPessoas()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[6];
            string auxiliar="", auxiliar2="";
            int[] tamanho = new int[6];

            for (var i = 0; i < 6; i++)
            {
                auxiliar = Interaction.InputBox("Digite um nome completo: " + (i + 1), "Entrada de dados");
                auxiliar2 = auxiliar.Replace(" ", "");
                tamanho[i] = auxiliar2.Length;

               lstbxDados.Items.Add("O nome " + auxiliar + " tem " + tamanho[i].ToString() + " caracteres.");
            }
        }
    }
}
